import re

def is_strong_password(password):
    """
    Checks if the password is strong based on:
    - Minimum 8 characters
    - At least one uppercase letter
    - At least one lowercase letter
    - At least one digit
    - At least one special character from !@#$%^&*
    """
    if len(password) < 8:
        print("❌ Password too short! Must be at least 8 characters.")
        return False
    if not re.search(r"[A-Z]", password):
        print("❌ Password must contain at least one uppercase letter.")
        return False
    if not re.search(r"[a-z]", password):
        print("❌ Password must contain at least one lowercase letter.")
        return False
    if not re.search(r"[0-9]", password):
        print("❌ Password must contain at least one digit.")
        return False
    if not re.search(r"[!@#$%^&*]", password):
        print("❌ Password must contain at least one special character (!@#$%^&*)")
        return False
    return True

def main():
    print("🔐 Password Strength Checker")
    password = input("Enter your password: ")
    
    if is_strong_password(password):
        print("✅ Password is strong.")
    else:
        print("⚠️ Please choose a stronger password.")

if __name__ == "__main__":
    main()
