import os
import json
from data_handler import export_to_vault, import_from_vault, import_from_csv

# Example vault structure
vault = {
    "entries": []
}

def save_vault(path='vault.json'):
    with open(path, "w") as f:
        json.dump(vault, f, indent=2)

def load_vault(path='vault.json'):
    global vault
    if os.path.exists(path):
        with open(path) as f:
            vault = json.load(f)

def handle_export(password):
    export_to_vault(vault, password)
    print("✅ Exported to backup.vault")

def handle_import(password):
    data = import_from_vault(password)
    if data:
        global vault
        vault = data
        save_vault()
        print("✅ Vault imported successfully.")

def handle_csv_import(csv_path):
    entries = import_from_csv(csv_path)
    vault['entries'].extend(entries)
    save_vault()
    print(f"✅ Imported {len(entries)} entries from CSV.")

# Test Example
if __name__ == "__main__":
    load_vault()

    print("1. Export Vault")
    print("2. Import Vault")
    print("3. Import CSV")
    choice = input("Choose: ")

    password = input("🔐 Enter your vault password: ")

    if choice == '1':
        handle_export(password)
    elif choice == '2':
        handle_import(password)
    elif choice == '3':
        csv_path = input("📂 CSV Path: ")
        handle_csv_import(csv_path)
