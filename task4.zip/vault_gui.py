import tkinter as tk
from tkinter import ttk
from ttkthemes import ThemedTk
from plyer import notification

# ---------- Toast Notification ----------
def show_notification(title, message):
    notification.notify(
        title=title,
        message=message,
        timeout=3
    )

# ---------- Main App ----------
class VaultApp:
    def __init__(self, root):
        self.root = root
        self.theme_mode = "default"
        self.setup_ui()

    def setup_ui(self):
        self.root.title("🔐 Secure Vault")
        self.root.state("zoomed")  # Fullscreen window
        self.root.configure(bg="#f0f0f0")

        # Configure columns and rows
        self.root.columnconfigure(1, weight=1)
        self.root.rowconfigure(1, weight=1)

        # Top Bar
        topbar = tk.Frame(self.root, height=50, bg="#444")
        topbar.grid(row=0, column=0, columnspan=2, sticky="ew")
        tk.Label(topbar, text="🔐 Vault Manager", bg="#444", fg="white", font=("Arial", 16)).pack(side="left", padx=20)
        tk.Button(topbar, text="🔒 Lock", command=self.lock_vault, bg="#222", fg="white").pack(side="right", padx=10, pady=5)

        # Sidebar
        sidebar = tk.Frame(self.root, width=200, bg="#333")
        sidebar.grid(row=1, column=0, sticky="ns")
        for text, cmd in [("🏠 Home", self.home),
                          ("➕ Add", self.add_entry),
                          ("🔍 Search", self.search),
                          ("⚙ Settings", self.settings)]:
            btn = tk.Button(sidebar, text=text, bg="#333", fg="white", relief="flat", font=("Arial", 12),
                            command=cmd)
            btn.pack(fill="x", pady=5, padx=10)

        # Main Content Area
        self.content = tk.Frame(self.root, bg="white")
        self.content.grid(row=1, column=1, sticky="nsew")
        self.home()

    # ---------- Page Methods ----------
    def home(self):
        self.clear_content()
        ttk.Label(self.content, text="🏠 Welcome to the Vault", font=("Arial", 18)).pack(pady=40)
        show_notification("Vault Unlocked", "Welcome to your secure vault!")

    def add_entry(self):
        self.clear_content()
        ttk.Label(self.content, text="➕ Add New Secret", font=("Arial", 18)).pack(pady=40)
        show_notification("Add Entry", "Add a new vault entry.")

    def search(self):
        self.clear_content()
        ttk.Label(self.content, text="🔍 Search Vault", font=("Arial", 18)).pack(pady=40)
        show_notification("Search", "Search your vault.")

    def settings(self):
        self.clear_content()
        ttk.Label(self.content, text="⚙ Settings", font=("Arial", 18)).pack(pady=20)

        theme_btn = ttk.Button(self.content, text="🌓 Toggle Theme", command=self.toggle_theme)
        theme_btn.pack(pady=10)

    def lock_vault(self):
        show_notification("Vault Locked", "Your vault has been locked!")
        self.root.destroy()

    def clear_content(self):
        for widget in self.content.winfo_children():
            widget.destroy()

    # ---------- Theme Toggle ----------
    def toggle_theme(self):
        if self.theme_mode == "default":
            self.root.set_theme("black")
            self.theme_mode = "dark"
        else:
            self.root.set_theme("default")
            self.theme_mode = "default"
        show_notification("Theme Changed", f"Switched to {self.theme_mode.capitalize()} Mode")

# ---------- Launch ----------
if __name__ == "__main__":
    root = ThemedTk(theme="default")  # Use themed root
    app = VaultApp(root)
    root.mainloop()
