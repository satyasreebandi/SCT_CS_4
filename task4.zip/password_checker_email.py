import re
import smtplib
from tkinter import *
from tkinter import messagebox
from email.message import EmailMessage

# ---------------------- Password Strength Checker ----------------------
def check_strength(password):
    if len(password) < 8:
        return "❌ Too short"
    if not re.search(r"[A-Z]", password):
        return "❌ No uppercase letter"
    if not re.search(r"[a-z]", password):
        return "❌ No lowercase letter"
    if not re.search(r"[0-9]", password):
        return "❌ No digit"
    if not re.search(r"[\W_]", password):
        return "❌ No special character"
    return "✅ Strong"

# ---------------------- Send Email Function ----------------------
def send_email(receiver_email, password):
    try:
        sender_email = "satyabandibandi@gmail.com"  # Replace with your Gmail
        app_password = "euve resn oljh jsyv"     # Replace with your app password

        msg = EmailMessage()
        msg['Subject'] = 'Your Strong Password'
        msg['From'] = sender_email
        msg['To'] = receiver_email
        msg.set_content(f"Here is your strong password:\n\n{password}")

        with smtplib.SMTP_SSL('smtp.gmail.com', 465) as smtp:
            smtp.login(sender_email, app_password)
            smtp.send_message(msg)

        messagebox.showinfo("✅ Email Sent", f"Password sent to {receiver_email}")
    except Exception as e:
        messagebox.showerror("❌ Email Failed", f"Error: {str(e)}")

# ---------------------- GUI ----------------------
def check_and_update():
    pwd = password_entry.get()
    strength = check_strength(pwd)
    result_label.config(text=f"Strength: {strength}")
    if "✅" in strength:
        email_button.config(state=NORMAL)
    else:
        email_button.config(state=DISABLED)

def email_password():
    pwd = password_entry.get()
    email = email_entry.get()
    if not email:
        messagebox.showwarning("⚠️ Enter Email", "Please enter your email.")
        return
    send_email(email, pwd)

# ---------------------- App Setup ----------------------
root = Tk()
root.title("🔐 Password Strength Checker + Email")
root.geometry("400x300")
root.config(padx=20, pady=20)

Label(root, text="Enter Password:").pack()
password_entry = Entry(root, width=30, show='*')
password_entry.pack(pady=5)

check_btn = Button(root, text="Check Strength", command=check_and_update)
check_btn.pack(pady=5)

result_label = Label(root, text="Strength: ", fg="blue")
result_label.pack()

Label(root, text="Your Email (to receive password):").pack(pady=10)
email_entry = Entry(root, width=30)
email_entry.pack()

email_button = Button(root, text="📧 Email Password", state=DISABLED, command=email_password)
email_button.pack(pady=15)

root.mainloop()
