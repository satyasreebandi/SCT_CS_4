from cryptography.fernet import Fernet
import os
from config import get_log_filename, KEY_FILE

def load_key():
    if not os.path.exists(KEY_FILE):
        key = Fernet.generate_key()
        with open(KEY_FILE, 'wb') as f:
            f.write(key)
    else:
        with open(KEY_FILE, 'rb') as f:
            key = f.read()
    return Fernet(key)

def encrypt_log(data):
    os.makedirs("logs", exist_ok=True)
    f = load_key()
    encrypted_data = f.encrypt(data.encode())
    log_file = get_log_filename()
    with open(log_file, 'ab') as log:
        log.write(encrypted_data + b'\n')
