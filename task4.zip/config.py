import os
from datetime import date

KEY_FILE = "secret.key"

def get_log_filename():
    today = date.today().isoformat()
    return os.path.join("logs", f"keylog_{today}.enc")
