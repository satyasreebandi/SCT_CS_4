import sqlite3
import datetime

DB_FILE = "vault_history.db"

def init_history_db():
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("""
        CREATE TABLE IF NOT EXISTS history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            entry_title TEXT,
            action TEXT,
            timestamp TEXT,
            details TEXT
        )
    """)
    conn.commit()
    conn.close()

def log_action(entry_title, action, details=""):
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    timestamp = datetime.datetime.now().isoformat()
    c.execute("INSERT INTO history (entry_title, action, timestamp, details) VALUES (?, ?, ?, ?)",
              (entry_title, action, timestamp, details))
    conn.commit()
    conn.close()

def fetch_history(entry_title=None):
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    if entry_title:
        c.execute("SELECT * FROM history WHERE entry_title = ? ORDER BY timestamp DESC", (entry_title,))
    else:
        c.execute("SELECT * FROM history ORDER BY timestamp DESC")
    rows = c.fetchall()
    conn.close()
    return rows
