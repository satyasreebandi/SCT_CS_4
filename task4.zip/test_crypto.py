import unittest
from utils import encrypt_data, decrypt_data, generate_key

class TestVaultCrypto(unittest.TestCase):
    def setUp(self):
        self.password = "testpassword"
        self.key = generate_key(self.password)
        self.data = "SensitiveVaultData123"

    def test_encryption_decryption(self):
        encrypted = encrypt_data(self.data, self.key)
        decrypted = decrypt_data(encrypted, self.key)
        self.assertEqual(self.data, decrypted)

    def test_wrong_password(self):
        wrong_key = generate_key("wrongpassword")
        encrypted = encrypt_data(self.data, self.key)
        with self.assertRaises(Exception):
            decrypt_data(encrypted, wrong_key)

if __name__ == "__main__":
    unittest.main()
