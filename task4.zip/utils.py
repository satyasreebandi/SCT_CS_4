# utils.py
import json
import os
from cryptography.fernet import Fernet
from datetime import datetime
import base64
import hashlib

VAULT_FILE = "vault.json.enc"

def generate_key(password: str) -> bytes:
    salt = b"static_salt_123"  # Replace with random salt & store separately for better security
    kdf = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 100000)
    return base64.urlsafe_b64encode(kdf)

def encrypt_data(data: dict, key: bytes) -> None:
    f = Fernet(key)
    encrypted = f.encrypt(json.dumps(data).encode())
    with open(VAULT_FILE, "wb") as file:
        file.write(encrypted)

def decrypt_data(key: bytes) -> dict:
    if not os.path.exists(VAULT_FILE):
        return {"entries": []}
    f = Fernet(key)
    with open(VAULT_FILE, "rb") as file:
        decrypted = f.decrypt(file.read())
    return json.loads(decrypted.decode())

def get_timestamp() -> str:
    return datetime.now().strftime("%Y-%m-%d")
