from flask import Flask, render_template, request, redirect, url_for, jsonify, session
from utils import encrypt_vault, decrypt_vault
import json, os

app = Flask(__name__)
app.secret_key = 'super-secret-key'  # Use env var in production
VAULT_FILE = 'vault.json'

# Load encrypted vault from file
def load_vault():
    if os.path.exists(VAULT_FILE):
        with open(VAULT_FILE, 'r') as f:
            return f.read()
    return ''

# Save encrypted vault to file
def save_vault(enc_data):
    with open(VAULT_FILE, 'w') as f:
        f.write(enc_data)

@app.route('/')
def home():
    if not session.get('unlocked'):
        return redirect(url_for('login'))
    vault = session.get('vault_data', [])
    return render_template('index.html', entries=vault)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        password = request.form['password']
        encrypted = load_vault()
        if encrypted:
            data = decrypt_vault(encrypted, password)
            if data is None:
                return render_template('login.html', error="Invalid password")
            session['vault_data'] = data
        else:
            session['vault_data'] = []
        session['unlocked'] = True
        session['password'] = password
        return redirect(url_for('home'))
    return render_template('login.html')

@app.route('/add', methods=['POST'])
def add_entry():
    if not session.get('unlocked'):
        return redirect(url_for('login'))
    entry = {
        "title": request.form['title'],
        "username": request.form['username'],
        "password": request.form['password'],
        "url": request.form['url'],
        "notes": request.form['notes']
    }
    vault = session['vault_data']
    vault.append(entry)
    session['vault_data'] = vault
    enc = encrypt_vault(vault, session['password'])
    save_vault(enc)
    return redirect(url_for('home'))

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(debug=True)
