import json
import sqlite3
import datetime
import os

VAULT_FILE = "vault.json"
HISTORY_DB = "vault_history.db"

# ------------------- History Logging -------------------

def init_history_db():
    conn = sqlite3.connect(HISTORY_DB)
    c = conn.cursor()
    c.execute("""
        CREATE TABLE IF NOT EXISTS history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            entry_title TEXT,
            action TEXT,
            timestamp TEXT,
            details TEXT
        )
    """)
    conn.commit()
    conn.close()

def log_action(entry_title, action, details=""):
    conn = sqlite3.connect(HISTORY_DB)
    c = conn.cursor()
    timestamp = datetime.datetime.now().isoformat()
    c.execute("INSERT INTO history (entry_title, action, timestamp, details) VALUES (?, ?, ?, ?)",
              (entry_title, action, timestamp, details))
    conn.commit()
    conn.close()

def fetch_history(entry_title=None):
    conn = sqlite3.connect(HISTORY_DB)
    c = conn.cursor()
    if entry_title:
        c.execute("SELECT * FROM history WHERE entry_title = ? ORDER BY timestamp DESC", (entry_title,))
    else:
        c.execute("SELECT * FROM history ORDER BY timestamp DESC")
    rows = c.fetchall()
    conn.close()
    return rows

def print_history_logs(entry_title=None):
    logs = fetch_history(entry_title)
    for log in logs:
        print(f"[{log[3]}] {log[2].upper()} - {log[1]} :: {log[4]}")

# ------------------- Vault Logic -------------------

def load_vault():
    if not os.path.exists(VAULT_FILE):
        return {"entries": []}
    try:
        with open(VAULT_FILE, "r") as f:
            data = json.load(f)
            if "entries" not in data:
                data["entries"] = []
            return data
    except (json.JSONDecodeError, FileNotFoundError):
        print("⚠️ Vault file missing or corrupted. Resetting vault.")
        return {"entries": []}

def save_vault(data):
    with open(VAULT_FILE, "w") as f:
        json.dump(data, f, indent=2)

def add_entry(vault_data, new_entry):
    vault_data["entries"].append(new_entry)
    log_action(new_entry["title"], "added", f"Tags: {new_entry.get('tags', [])}")

def edit_entry(vault_data, title, updated_data):
    for entry in vault_data["entries"]:
        if entry["title"] == title:
            old = entry.copy()
            entry.update(updated_data)
            log_action(title, "edited", f"Old: {old}, New: {entry}")
            return True
    return False

def delete_entry(vault_data, title):
    for i, entry in enumerate(vault_data["entries"]):
        if entry["title"] == title:
            removed = vault_data["entries"].pop(i)
            log_action(title, "deleted", f"{removed}")
            return removed
    return None

def rollback_deleted_entry(vault_data, deleted_entry):
    vault_data["entries"].append(deleted_entry)
    log_action(deleted_entry["title"], "rollback", "Rolled back deleted entry.")

# ------------------- Test CLI -------------------

if __name__ == "__main__":
    init_history_db()
    vault = load_vault()

    print("🔐 Vault Manager + History")
    print("1. Add Entry")
    print("2. Edit Entry")
    print("3. Delete Entry")
    print("4. Rollback Last Deleted")
    print("5. Show History")
    print("6. Exit")

    last_deleted = None

    while True:
        choice = input("\nEnter choice: ")
        if choice == "1":
            title = input("Title: ")
            username = input("Username: ")
            password = input("Password: ")
            tags = input("Tags (comma): ").split(",")
            entry = {
                "title": title,
                "username": username,
                "password": password,
                "tags": [tag.strip() for tag in tags],
                "created_at": datetime.datetime.now().isoformat()
            }
            add_entry(vault, entry)
            save_vault(vault)
            print("✅ Added.")

        elif choice == "2":
            title = input("Title to edit: ")
            username = input("New Username: ")
            password = input("New Password: ")
            updated = {
                "username": username,
                "password": password,
                "modified_at": datetime.datetime.now().isoformat()
            }
            if edit_entry(vault, title, updated):
                save_vault(vault)
                print("✅ Edited.")
            else:
                print("❌ Entry not found.")

        elif choice == "3":
            title = input("Title to delete: ")
            deleted = delete_entry(vault, title)
            if deleted:
                last_deleted = deleted
                save_vault(vault)
                print("🗑️ Deleted.")
            else:
                print("❌ Entry not found.")

        elif choice == "4":
            if last_deleted:
                rollback_deleted_entry(vault, last_deleted)
                save_vault(vault)
                print("♻️ Rolled back.")
            else:
                print("⚠️ No deleted entry to rollback.")

        elif choice == "5":
            print("\n📜 History Logs:")
            print_history_logs()

        elif choice == "6":
            print("🔒 Exiting vault...")
            break

        else:
            print("❓ Invalid choice.")
