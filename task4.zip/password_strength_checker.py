import re
import os
from getpass import getpass
from cryptography.fernet import Fernet

# ------------------- 🔐 Setup Encryption Key -------------------
def load_or_create_key():
    if not os.path.exists("secret.key"):
        key = Fernet.generate_key()
        with open("secret.key", "wb") as f:
            f.write(key)
    else:
        with open("secret.key", "rb") as f:
            key = f.read()
    return Fernet(key)

fernet = load_or_create_key()

# ------------------- 🔎 Password Strength Check -------------------
def password_strength_level(password):
    score = 0
    if len(password) >= 8:
        score += 1
    if re.search(r"[A-Z]", password):
        score += 1
    if re.search(r"[a-z]", password):
        score += 1
    if re.search(r"[0-9]", password):
        score += 1
    if re.search(r"[!@#$%^&*]", password):
        score += 1

    if score <= 2:
        return "❌ Weak"
    elif score in [3, 4]:
        return "⚠️ Medium"
    else:
        return "✅ Strong"

def suggest_improvements(password):
    suggestions = []
    if len(password) < 8:
        suggestions.append("Increase length to 8+")
    if not re.search(r"[A-Z]", password):
        suggestions.append("Add uppercase letter")
    if not re.search(r"[a-z]", password):
        suggestions.append("Add lowercase letter")
    if not re.search(r"[0-9]", password):
        suggestions.append("Add digit")
    if not re.search(r"[!@#$%^&*]", password):
        suggestions.append("Add special character (!@#$%^&*)")
    return suggestions

# ------------------- 🔐 Encrypt and Save -------------------
def encrypt_and_save(password):
    encrypted = fernet.encrypt(password.encode())
    with open("strong_passwords.enc", "ab") as f:
        f.write(encrypted + b"\n")

# ------------------- 🧠 Main Program -------------------
def main():
    print("🔐 Password Strength Checker")
    password = getpass("Enter your password (hidden): ")

    strength = password_strength_level(password)
    print(f"🔍 Strength Level: {strength}")

    if strength == "✅ Strong":
        encrypt_and_save(password)
        print("🔐 Password encrypted and saved to strong_passwords.enc")
    else:
        print("💡 Suggestions to improve:")
        for tip in suggest_improvements(password):
            print(" -", tip)

if __name__ == "__main__":
    main()
