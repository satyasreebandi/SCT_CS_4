import os
import json
import base64
import smtplib
from email.message import EmailMessage
from tkinter import *
from tkinter import messagebox, filedialog, simpledialog
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes
from cryptography.fernet import Fernet

# ==== Crypto Utils ====

def derive_key(password: str, salt: bytes) -> bytes:
    kdf = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=salt, iterations=390000)
    return base64.urlsafe_b64encode(kdf.derive(password.encode()))

def encrypt_vault_data(data: dict, password: str) -> bytes:
    salt = os.urandom(16)
    key = derive_key(password, salt)
    fernet = Fernet(key)
    encrypted = fernet.encrypt(json.dumps(data).encode())
    return salt + encrypted

def decrypt_vault_file(file_path: str, password: str) -> dict:
    with open(file_path, 'rb') as f:
        content = f.read()
    salt = content[:16]
    encrypted = content[16:]
    key = derive_key(password, salt)
    fernet = Fernet(key)
    decrypted = fernet.decrypt(encrypted)
    return json.loads(decrypted.decode())

# ==== Email ====

def send_email(file_path, to_email, from_email, app_password):
    email = EmailMessage()
    email['Subject'] = 'Encrypted Vault Backup'
    email['From'] = from_email
    email['To'] = to_email
    with open(file_path, 'rb') as f:
        email.add_attachment(f.read(), maintype='application', subtype='octet-stream', filename=os.path.basename(file_path))
    with smtplib.SMTP_SSL('smtp.gmail.com', 465) as smtp:
        smtp.login(from_email, app_password)
        smtp.send_message(email)

# ==== GUI Functions ====

vault_data = {}
vault_path = None

def load_vault():
    global vault_path, vault_data
    vault_path = filedialog.askopenfilename(title="Select vault.enc")
    if not vault_path: return
    password = password_entry.get()
    if not password:
        messagebox.showerror("Missing", "Enter password to decrypt.")
        return
    try:
        vault_data = decrypt_vault_file(vault_path, password)
        refresh_listbox()
        messagebox.showinfo("Decrypted", f"Vault decrypted.")
    except Exception as e:
        messagebox.showerror("Error", str(e))

def refresh_listbox():
    listbox.delete(0, END)
    for key in vault_data:
        listbox.insert(END, key)

def add_secret():
    key = simpledialog.askstring("Add Secret", "Enter service/site:")
    value = simpledialog.askstring("Password", f"Enter password for {key}:")
    if key and value:
        vault_data[key] = value
        refresh_listbox()

def delete_secret():
    selected = listbox.curselection()
    if not selected: return
    key = listbox.get(selected[0])
    del vault_data[key]
    refresh_listbox()

def view_secret():
    selected = listbox.curselection()
    if not selected: return
    key = listbox.get(selected[0])
    value = vault_data[key]
    messagebox.showinfo(key, f"Password: {value}")

def save_vault():
    if not vault_data:
        messagebox.showerror("Error", "No vault data.")
        return
    password = password_entry.get()
    if not password:
        messagebox.showerror("Missing", "Enter password to save.")
        return
    out_path = filedialog.asksaveasfilename(defaultextension=".enc", filetypes=[("Encrypted Files", "*.enc")])
    if not out_path: return
    try:
        encrypted = encrypt_vault_data(vault_data, password)
        with open(out_path, 'wb') as f:
            f.write(encrypted)
        messagebox.showinfo("Saved", f"Encrypted vault saved to:\n{out_path}")
    except Exception as e:
        messagebox.showerror("Error", str(e))

def send_backup():
    path = filedialog.askopenfilename(title="Select Encrypted Vault")
    if not path: return
    to_email = email_entry.get()
    from_email = sender_entry.get()
    app_pass = app_pass_entry.get()
    if not all([to_email, from_email, app_pass]):
        messagebox.showerror("Missing", "Fill all email fields.")
        return
    try:
        send_email(path, to_email, from_email, app_pass)
        messagebox.showinfo("Sent", f"Sent to: {to_email}")
    except Exception as e:
        messagebox.showerror("Email Failed", str(e))

# ==== GUI ====

root = Tk()
root.title("🔐 AES Vault Manager")
root.geometry("500x500")

Label(root, text="Vault Password").pack()
password_entry = Entry(root, show="*", width=30)
password_entry.pack()

Button(root, text="📂 Load & Decrypt Vault", command=load_vault).pack(pady=5)
Button(root, text="💾 Save Vault (Encrypted)", command=save_vault).pack(pady=5)

Label(root, text="Vault Entries").pack(pady=5)
listbox = Listbox(root, width=40, height=10)
listbox.pack()

Button(root, text="➕ Add Secret", command=add_secret).pack()
Button(root, text="🗑️ Delete Secret", command=delete_secret).pack()
Button(root, text="👁 View Password", command=view_secret).pack(pady=5)

Label(root, text="📧 Email Backup (Optional)", font=('Arial', 10, 'bold')).pack(pady=10)
Label(root, text="Sender Email").pack()
sender_entry = Entry(root, width=35)
sender_entry.pack()
Label(root, text="App Password").pack()
app_pass_entry = Entry(root, show="*", width=35)
app_pass_entry.pack()
Label(root, text="Recipient Email").pack()
email_entry = Entry(root, width=35)
email_entry.pack()
Button(root, text="📤 Send Vault to Email", command=send_backup).pack(pady=5)

root.mainloop()
