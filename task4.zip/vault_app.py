import win32com.client
import tkinter as tk
from tkinter import messagebox
from cryptography.fernet import Fernet
import os

VAULT_FILE = "secure_data.enc"
SECRET_KEY = b"U1t_Ultra_Secret_Password_Key_1234567890!!"[:32]  # Must be 32 bytes

def encrypt_data(data, key):
    return Fernet(base64.urlsafe_b64encode(key)).encrypt(data.encode())

def decrypt_data(data, key):
    return Fernet(base64.urlsafe_b64encode(key)).decrypt(data).decode()

def save_vault(data):
    enc = encrypt_data(data, SECRET_KEY)
    with open(VAULT_FILE, "wb") as f:
        f.write(enc)

def load_vault():
    if not os.path.exists(VAULT_FILE):
        return None
    with open(VAULT_FILE, "rb") as f:
        return decrypt_data(f.read(), SECRET_KEY)

def prompt_windows_credential():
    credential_manager = win32com.client.Dispatch("WScript.Network")
    username = credential_manager.UserName
    return username  # basic validation

# ---------- GUI ----------
class VaultApp:
    def __init__(self, root):
        self.root = root
        self.root.title("🔐 Windows Credential Vault")
        self.root.geometry("400x300")

        self.label = tk.Label(root, text="🔑 Click to Unlock", font=("Arial", 14))
        self.label.pack(pady=20)

        self.unlock_btn = tk.Button(root, text="🔓 Unlock", command=self.authenticate)
        self.unlock_btn.pack(pady=10)

        self.text = tk.Text(root, height=10, width=40)
        self.text.pack(pady=10)

    def authenticate(self):
        try:
            username = prompt_windows_credential()
            if username:
                decrypted = load_vault()
                self.text.delete(1.0, tk.END)
                self.text.insert(tk.END, decrypted or "Vault is empty.")
                messagebox.showinfo("✅ Access Granted", f"Welcome {username}")
            else:
                messagebox.showerror("❌ Failed", "Authentication Failed")
        except Exception as e:
            messagebox.showerror("Error", str(e))

def setup_vault():
    if not os.path.exists(VAULT_FILE):
        save_vault("This is your encrypted vault content! 🔒")

if __name__ == "__main__":
    setup_vault()
    root = tk.Tk()
    app = VaultApp(root)
    root.mainloop()
