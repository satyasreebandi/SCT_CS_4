import base64
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes
from cryptography.fernet import Fernet
from getpass import getpass

def derive_key(password: str, salt: bytes) -> bytes:
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=390000,
    )
    return base64.urlsafe_b64encode(kdf.derive(password.encode()))

def decrypt_file(file_path, password):
    with open(file_path, 'rb') as f:
        content = f.read()

    salt = content[:16]
    encrypted = content[16:]

    key = derive_key(password, salt)
    fernet = Fernet(key)
    decrypted = fernet.decrypt(encrypted)

    print("🔓 Vault contents:")
    print(decrypted.decode())

if __name__ == "__main__":
    password = getpass("🔑 Enter password to decrypt: ")
    decrypt_file("vault.json.enc", password)
