from core.encryption import generate_aes_key
from core.pin_manager import save_encrypted_vault_key, load_vault_key_from_pin
from core.vault_manager import (
    save_vault, load_vault, add_entry, view_entries,
    search_entries, update_entry, delete_entry
)
from core.backup import create_local_backup, send_email_backup_prompt

vault_data = []
vault_key = None
vault_loaded = False


def setup_vault():
    global vault_key
    pin = input("🔐 Set a new 4-digit PIN: ").strip()
    if len(pin) != 4 or not pin.isdigit():
        print("❌ PIN must be a 4-digit number.")
        return
    key = generate_aes_key()
    save_encrypted_vault_key(key, pin)
    print("✅ Vault setup completed.")
    vault_key = key


def unlock_vault():
    global vault_data, vault_key, vault_loaded
    if vault_loaded:
        print("🔓 Vault already unlocked.")
        return
    pin = input("🔑 Enter your 4-digit PIN: ").strip()
    try:
        key = load_vault_key_from_pin(pin)
        vault_data = load_vault(key)
        vault_key = key
        vault_loaded = True
        print("✅ Vault unlocked.")
    except Exception as e:
        print("❌ Failed to unlock vault. Reason:", str(e))


def save_and_exit():
    if vault_key and vault_data:
        save_vault(vault_key, vault_data)
        print("💾 Vault saved.")
    print("👋 Exiting...")


def main_menu():
    while True:
        print("\n=== 🔐 Secure Vault Menu ===")
        print("1. Setup Vault")
        print("2. Unlock Vault")
        print("3. Add Entry")
        print("4. View All Entries")
        print("5. Backup Vault (Local)")
        print("6. Email Backup (Gmail App Password)")
        print("7. Search Entry")
        print("8. Update Entry")
        print("9. Delete Entry")
        print("0. Exit")

        choice = input("Choose: ").strip()

        if choice == '1':
            setup_vault()
        elif choice == '2':
            unlock_vault()
        elif choice == '3':
            if vault_loaded:
                site = input("Website/App: ")
                username = input("Username: ")
                password = input("Password: ")
                add_entry(vault_data, site, username, password)
                print("✅ Entry added.")
            else:
                print("🔒 Unlock the vault first.")
        elif choice == '4':
            if vault_loaded:
                view_entries(vault_data)
            else:
                print("🔒 Unlock the vault first.")
        elif choice == '5':
            create_local_backup()
        elif choice == '6':
            send_email_backup_prompt()
        elif choice == '7':
            if vault_loaded:
                keyword = input("🔍 Search keyword: ")
                results = search_entries(vault_data, keyword)
                view_entries(results)
            else:
                print("🔒 Unlock the vault first.")
        elif choice == '8':
            if vault_loaded:
                index = int(input("Index to update: "))
                site = input("New Website/App: ")
                username = input("New Username: ")
                password = input("New Password: ")
                update_entry(vault_data, index, site, username, password)
                print("✅ Entry updated.")
            else:
                print("🔒 Unlock the vault first.")
        elif choice == '9':
            if vault_loaded:
                index = int(input("Index to delete: "))
                delete_entry(vault_data, index)
                print("🗑️ Entry deleted.")
            else:
                print("🔒 Unlock the vault first.")
        elif choice == '0':
            save_and_exit()
            break
        else:
            print("❌ Invalid choice.")


if __name__ == "__main__":
    main_menu()
