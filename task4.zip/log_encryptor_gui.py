import tkinter as tk
from tkinter import filedialog, messagebox, simpledialog
from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes
import hashlib
import os
import json
import smtplib
import shutil
from email.message import EmailMessage
import datetime

# Create folders
os.makedirs("logs", exist_ok=True)
os.makedirs("sent_logs", exist_ok=True)

# GUI
root = tk.Tk()
root.title("🔐 Log Encryptor with Email & History")
root.geometry("800x700")

# Global widgets
text_preview = None
listbox_history = None
entry_email = None
entry_app_password = None

# --------- Encryption Functions ---------

def encrypt_log():
    if not os.path.exists("logs/log.txt"):
        with open("logs/log.txt", "w") as f:
            f.write("")  # create empty log

    password = simpledialog.askstring("Password", "Enter encryption password:", show="*")
    if not password:
        return

    with open("logs/log.txt", "rb") as f:
        data = f.read()

    salt = b"mysalt"
    key = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 100000)
    cipher = AES.new(key, AES.MODE_EAX)
    ciphertext, tag = cipher.encrypt_and_digest(data)

    encrypted_data = cipher.nonce + ciphertext

    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    username = os.getlogin()
    filename = f"log_{timestamp}_{username}.txt.enc"
    enc_path = os.path.join("sent_logs", filename)

    with open(enc_path, "wb") as f:
        f.write(encrypted_data)

    os.remove("logs/log.txt")

    messagebox.showinfo("Success", f"✅ Encrypted and saved as: {filename}")
    send_email(enc_path, filename)
    load_history()


# --------- Email Sending ---------

def send_email(filepath, filename):
    if not os.path.exists("email_config.json"):
        messagebox.showerror("Email Error", "Please save email config first.")
        return

    with open("email_config.json") as f:
        config = json.load(f)

    sender_email = config["email"]
    password = config["password"]
    receiver_email = sender_email

    msg = EmailMessage()
    msg['Subject'] = "🔐 Encrypted Log File"
    msg['From'] = sender_email
    msg['To'] = receiver_email
    msg.set_content("Attached is your encrypted log file.")

    with open(filepath, "rb") as f:
        file_data = f.read()

    msg.add_attachment(file_data, maintype="application", subtype="octet-stream", filename=filename)

    try:
        with smtplib.SMTP_SSL("smtp.gmail.com", 465) as smtp:
            smtp.login(sender_email, password)
            smtp.send_message(msg)
        messagebox.showinfo("Email", "📧 Encrypted file emailed successfully.")
    except Exception as e:
        messagebox.showerror("Email Failed", f"❌ Email failed:\n{e}")

# --------- Log Preview ---------

def preview_log():
    if not os.path.exists("logs/log.txt"):
        messagebox.showerror("Error", "log.txt not found!")
        return
    with open("logs/log.txt", "r", encoding="utf-8") as f:
        content = f.read()
    text_preview.delete("1.0", tk.END)
    text_preview.insert(tk.END, content)

# --------- Save Email Config ---------

def save_email_config():
    config = {
        "email": entry_email.get(),
        "password": entry_app_password.get()
    }
    with open("email_config.json", "w") as f:
        json.dump(config, f)
    messagebox.showinfo("Saved", "✅ Email config saved.")

# --------- Load Encryption History ---------

def load_history():
    listbox_history.delete(0, tk.END)
    for file in os.listdir("sent_logs"):
        listbox_history.insert(tk.END, file)

# --------- Decrypt Selected Log ---------

def decrypt_log():
    selected = listbox_history.curselection()
    if not selected:
        messagebox.showerror("Error", "Select a file from history.")
        return
    filename = listbox_history.get(selected[0])
    path = os.path.join("sent_logs", filename)

    password = simpledialog.askstring("Password", "Enter decryption password:", show="*")
    if not password:
        return

    try:
        with open(path, "rb") as f:
            encrypted_data = f.read()
        nonce = encrypted_data[:16]
        ciphertext = encrypted_data[16:]

        key = hashlib.pbkdf2_hmac("sha256", password.encode(), b"mysalt", 100000)
        cipher = AES.new(key, AES.MODE_EAX, nonce=nonce)
        decrypted = cipher.decrypt(ciphertext)

        preview_window = tk.Toplevel(root)
        preview_window.title("🔓 Decrypted Log Preview")
        text_area = tk.Text(preview_window, width=80, height=20)
        text_area.pack()
        text_area.insert(tk.END, decrypted.decode())

    except Exception as e:
        messagebox.showerror("Decryption Failed", str(e))

# --------- UI Components ---------

tk.Label(root, text="📄 Log File Preview (log.txt):", font=("Arial", 12, "bold")).pack()
text_preview = tk.Text(root, height=10, width=100)
text_preview.pack(pady=5)
tk.Button(root, text="👁️ Preview Log", command=preview_log).pack(pady=5)

tk.Button(root, text="🔐 Encrypt & Email Log", command=encrypt_log, bg="lightgreen").pack(pady=10)

tk.Label(root, text="📬 Email Settings", font=("Arial", 12, "bold")).pack(pady=(20, 0))
tk.Label(root, text="Email:").pack()
entry_email = tk.Entry(root, width=50)
entry_email.pack()

tk.Label(root, text="App Password:").pack()
entry_app_password = tk.Entry(root, show="*", width=50)
entry_app_password.pack()

tk.Button(root, text="💾 Save Email Config", command=save_email_config).pack(pady=5)

tk.Label(root, text="📜 Encrypted File History", font=("Arial", 12, "bold")).pack(pady=(20, 0))
listbox_history = tk.Listbox(root, width=80, height=10)
listbox_history.pack(pady=5)

tk.Button(root, text="🔁 Refresh History", command=load_history).pack(pady=5)
tk.Button(root, text="🔓 Decrypt Selected Log", command=decrypt_log, bg="lightblue").pack(pady=5)

load_history()

root.mainloop()
