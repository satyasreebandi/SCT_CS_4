import tkinter as tk
from tkinter import messagebox
import json, smtplib, ssl, random, string, os, hashlib
from email.message import EmailMessage
from cryptography.fernet import Fernet

DATA_FILE = "vault_data.json"

# 🔐 Generate a key from password
def derive_key(password):
    return hashlib.sha256(password.encode()).hexdigest()

# 🔑 Send email with token
def send_token_email(to_email, token):
    try:
        msg = EmailMessage()
        msg.set_content(f"Your PIN reset token is: {token}")
        msg["Subject"] = "Vault PIN Reset Token"
        msg["From"] = "your_email@gmail.com"
        msg["To"] = to_email

        context = ssl.create_default_context()
        with smtplib.SMTP_SSL("smtp.gmail.com", 465, context=context) as server:
            server.login("satyabandibandi@gmail.com", "euveresnoljhjsyv")  # Use Gmail app password
            server.send_message(msg)
    except Exception as e:
        messagebox.showerror("Email Error", str(e))

# 📄 Save data
def save_data(data):
    with open(DATA_FILE, "w") as f:
        json.dump(data, f)

# 📄 Load data
def load_data():
    if not os.path.exists(DATA_FILE):
        return {}
    with open(DATA_FILE, "r") as f:
        return json.load(f)

# 📤 Request reset token
def forgot_pin():
    data = load_data()
    if "email" not in data:
        messagebox.showerror("Error", "No recovery email found!")
        return

    token = ''.join(random.choices(string.digits, k=6))
    with open("token.txt", "w") as f:
        f.write(token)

    send_token_email(data["email"], token)
    messagebox.showinfo("Token Sent", f"A reset token has been sent to {data['email']}.")

# 🔁 Reset PIN
def reset_pin():
    def verify_token():
        user_token = token_entry.get()
        if not os.path.exists("token.txt"):
            messagebox.showerror("Error", "No token found!")
            return
        with open("token.txt", "r") as f:
            real_token = f.read()
        if user_token == real_token:
            new_pin = new_pin_entry.get()
            data = load_data()
            data["pin_hash"] = derive_key(new_pin)
            save_data(data)
            os.remove("token.txt")
            messagebox.showinfo("Success", "PIN reset successfully!")
            reset_win.destroy()
        else:
            messagebox.showerror("Error", "Invalid token!")

    reset_win = tk.Toplevel()
    reset_win.title("Reset PIN")

    tk.Label(reset_win, text="Enter Token:").pack()
    token_entry = tk.Entry(reset_win)
    token_entry.pack()

    tk.Label(reset_win, text="New PIN:").pack()
    new_pin_entry = tk.Entry(reset_win, show="*")
    new_pin_entry.pack()

    tk.Button(reset_win, text="Verify & Reset", command=verify_token).pack(pady=10)

# 📝 Save recovery data
def setup_account():
    pin = pin_entry.get()
    email = email_entry.get()
    phrase = phrase_entry.get()

    if not pin or not email or not phrase:
        messagebox.showerror("Missing Info", "All fields are required.")
        return

    data = {
        "pin_hash": derive_key(pin),
        "email": email,
        "recovery_phrase": derive_key(phrase)
    }
    save_data(data)
    messagebox.showinfo("Success", "Account setup complete!")

# ✅ Check PIN login
def login():
    entered = pin_entry.get()
    data = load_data()
    if derive_key(entered) == data.get("pin_hash"):
        messagebox.showinfo("Welcome", "Vault unlocked!")
    else:
        messagebox.showerror("Error", "Invalid PIN!")

# ✅ Check Recovery Phrase
def recover_with_phrase():
    phrase = phrase_entry.get()
    data = load_data()
    if derive_key(phrase) == data.get("recovery_phrase"):
        messagebox.showinfo("Valid", "You may reset PIN from menu.")
    else:
        messagebox.showerror("Invalid", "Recovery phrase does not match!")

# 🖼️ GUI Setup
root = tk.Tk()
root.title("🔐 Vault Login & Recovery")

tk.Label(root, text="Master PIN:").pack()
pin_entry = tk.Entry(root, show="*")
pin_entry.pack()

tk.Label(root, text="Recovery Email:").pack()
email_entry = tk.Entry(root)
email_entry.pack()

tk.Label(root, text="Recovery Phrase:").pack()
phrase_entry = tk.Entry(root, show="*")
phrase_entry.pack()

tk.Button(root, text="🔐 Login", command=login).pack(pady=5)
tk.Button(root, text="📝 Setup Account", command=setup_account).pack(pady=5)
tk.Button(root, text="📧 Forgot PIN?", command=forgot_pin).pack(pady=5)
tk.Button(root, text="🔁 Reset PIN with Token", command=reset_pin).pack(pady=5)
tk.Button(root, text="🔑 Verify Recovery Phrase", command=recover_with_phrase).pack(pady=5)

root.mainloop()
