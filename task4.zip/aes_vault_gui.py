import os
import base64
import json
import smtplib
from email.message import EmailMessage
from tkinter import *
from tkinter import messagebox, filedialog
from getpass import getpass
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes
from cryptography.fernet import Fernet

# ======================== KEY DERIVATION ========================

def derive_key(password: str, salt: bytes) -> bytes:
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=390000,
    )
    return base64.urlsafe_b64encode(kdf.derive(password.encode()))

# ======================== ENCRYPT ========================

def encrypt_vault(vault_path, password):
    with open(vault_path, 'rb') as f:
        data = f.read()

    try:
        json.loads(data.decode())  # check it's valid JSON
    except:
        raise ValueError("Vault must be valid JSON format.")

    salt = os.urandom(16)
    key = derive_key(password, salt)
    fernet = Fernet(key)
    encrypted = fernet.encrypt(data)

    out_path = vault_path + ".enc"
    with open(out_path, 'wb') as f:
        f.write(salt + encrypted)

    os.remove(vault_path)  # Auto-delete original vault
    return out_path

# ======================== DECRYPT ========================

def decrypt_vault(enc_path, password):
    with open(enc_path, 'rb') as f:
        content = f.read()

    salt = content[:16]
    encrypted = content[16:]

    key = derive_key(password, salt)
    fernet = Fernet(key)
    decrypted = fernet.decrypt(encrypted)
    return decrypted.decode()

# ======================== EMAIL ========================

def send_email_with_attachment(to_email, subject, file_path, from_email, app_password):
    email = EmailMessage()
    email['Subject'] = subject
    email['From'] = from_email
    email['To'] = to_email

    with open(file_path, 'rb') as f:
        file_data = f.read()
        file_name = os.path.basename(file_path)

    email.set_content(f"Attached is your encrypted vault: {file_name}")
    email.add_attachment(file_data, maintype='application', subtype='octet-stream', filename=file_name)

    with smtplib.SMTP_SSL('smtp.gmail.com', 465) as smtp:
        smtp.login(from_email, app_password)
        smtp.send_message(email)

# ======================== GUI FUNCTIONS ========================

def encrypt_action():
    file_path = filedialog.askopenfilename(title="Select vault.json")
    if not file_path:
        return

    password = password_entry.get()
    if not password:
        messagebox.showerror("Error", "Enter a password to encrypt.")
        return

    try:
        out_path = encrypt_vault(file_path, password)
        messagebox.showinfo("✅ Encrypted", f"Vault encrypted to:\n{out_path}")
    except Exception as e:
        messagebox.showerror("❌ Error", str(e))

def decrypt_action():
    file_path = filedialog.askopenfilename(title="Select vault.json.enc")
    if not file_path:
        return

    password = password_entry.get()
    if not password:
        messagebox.showerror("Error", "Enter password to decrypt.")
        return

    try:
        decrypted = decrypt_vault(file_path, password)
        messagebox.showinfo("🔓 Vault Content", decrypted)
    except Exception as e:
        messagebox.showerror("❌ Decryption Failed", str(e))

def email_action():
    enc_file = filedialog.askopenfilename(title="Select Encrypted Vault File")
    if not enc_file:
        return

    to_email = email_entry.get()
    app_pass = app_pass_entry.get()
    from_email = sender_entry.get()

    if not all([to_email, from_email, app_pass]):
        messagebox.showerror("Missing Info", "Fill in all email fields.")
        return

    try:
        send_email_with_attachment(to_email, "Encrypted Vault Backup", enc_file, from_email, app_pass)
        messagebox.showinfo("📧 Sent", f"Email sent to: {to_email}")
    except Exception as e:
        messagebox.showerror("❌ Email Error", str(e))

# ======================== GUI ========================

root = Tk()
root.title("🔐 AES Encrypted Vault")
root.geometry("450x420")
root.resizable(False, False)

Label(root, text="Vault Password", font=("Arial", 12)).pack(pady=8)
password_entry = Entry(root, show='*', font=("Arial", 12), width=30)
password_entry.pack()

Button(root, text="🔒 Encrypt Vault", command=encrypt_action, font=("Arial", 12), bg="#aad", width=25).pack(pady=10)
Button(root, text="🔓 Decrypt Vault", command=decrypt_action, font=("Arial", 12), bg="#ada", width=25).pack(pady=5)

Label(root, text="📧 Email Backup (Optional)", font=("Arial", 12, "bold")).pack(pady=15)

Label(root, text="Sender Gmail", font=("Arial", 10)).pack()
sender_entry = Entry(root, width=40)
sender_entry.pack()

Label(root, text="App Password", font=("Arial", 10)).pack()
app_pass_entry = Entry(root, show="*", width=40)
app_pass_entry.pack()

Label(root, text="Recipient Email", font=("Arial", 10)).pack()
email_entry = Entry(root, width=40)
email_entry.pack()

Button(root, text="📤 Send Encrypted Vault", command=email_action, font=("Arial", 11), bg="#ffd", width=30).pack(pady=10)

root.mainloop()
