import base64
import hashlib
import json
import csv
import logging
import unittest
from cryptography.fernet import Fernet

# ========== 🔐 ENCRYPTION UTILITIES ==========

def generate_key(password):
    """Generate Fernet key using SHA-256 hash of the password."""
    key = hashlib.sha256(password.encode()).digest()
    return base64.urlsafe_b64encode(key)

def encrypt_data(data, key):
    """Encrypt string data using Fernet key."""
    f = Fernet(key)
    return f.encrypt(data.encode())

def decrypt_data(encrypted, key):
    """Decrypt Fernet encrypted data using key."""
    f = Fernet(key)
    return f.decrypt(encrypted).decode()

# ========== 🪵 LOGGING SETUP ==========
logging.basicConfig(filename='vault.log', level=logging.INFO,
                    format='%(asctime)s - %(levelname)s - %(message)s')

def log_action(action):
    logging.info(action)

# ========== 🗂️ CSV EXPORT FUNCTION ==========

def export_vault_to_csv(encrypted_file_path, password, output_file="vault_export.csv"):
    key = generate_key(password)
    with open(encrypted_file_path, "rb") as f:
        encrypted_data = f.read()

    try:
        decrypted = decrypt_data(encrypted_data, key)
        data = json.loads(decrypted)
    except Exception as e:
        print("❌ Failed to decrypt vault:", str(e))
        return

    with open(output_file, "w", newline='', encoding="utf-8") as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=["title", "username", "password", "url", "notes"])
        writer.writeheader()
        for entry in data:
            writer.writerow(entry)

    log_action("Vault exported to CSV.")
    print(f"✅ Vault exported to {output_file}")

# ========== 💾 SAVE ENCRYPTED VAULT FILE ==========

def save_encrypted_vault(data_list, password, path="vault_data.json"):
    key = generate_key(password)
    encrypted = encrypt_data(json.dumps(data_list), key)
    with open(path, "wb") as f:
        f.write(encrypted)
    log_action("Vault saved.")

# ========== ✅ SAMPLE VAULT DATA ==========
sample_data = [
    {
        "title": "Gmail",
        "username": "user@gmail.com",
        "password": "mypassword123",
        "url": "https://mail.google.com",
        "notes": "Personal email"
    },
    {
        "title": "Facebook",
        "username": "user123",
        "password": "securepass456",
        "url": "https://facebook.com",
        "notes": "Old account"
    }
]

# ========== 🧪 UNIT TESTS ==========

class TestVaultCrypto(unittest.TestCase):
    def setUp(self):
        self.password = "test123"
        self.key = generate_key(self.password)
        self.sample_data = "SecretInfo"

    def test_encrypt_decrypt(self):
        encrypted = encrypt_data(self.sample_data, self.key)
        decrypted = decrypt_data(encrypted, self.key)
        self.assertEqual(self.sample_data, decrypted)

    def test_decrypt_with_wrong_password(self):
        encrypted = encrypt_data(self.sample_data, self.key)
        wrong_key = generate_key("wrongpass")
        with self.assertRaises(Exception):
            decrypt_data(encrypted, wrong_key)

# ========== 🏃 RUN MODES ==========
if __name__ == "__main__":
    import sys

    print("🔐 Vault Tool")
    print("1. Save Sample Vault")
    print("2. Export Vault to CSV")
    print("3. Run Unit Tests")
    choice = input("Choose option (1/2/3): ").strip()

    if choice == "1":
        password = input("Enter password to encrypt vault: ")
        save_encrypted_vault(sample_data, password)
        print("✅ Vault saved as 'vault_data.json'")
    elif choice == "2":
        password = input("Enter password to decrypt vault: ")
        export_vault_to_csv("vault_data.json", password)
    elif choice == "3":
        print("🧪 Running tests...")
        unittest.main(argv=[sys.argv[0]])
    else:
        print("❌ Invalid choice.")
