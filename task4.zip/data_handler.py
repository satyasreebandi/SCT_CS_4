import json, csv, os
from crypto_utils import encrypt_data, decrypt_data, generate_key

def export_to_vault(vault_data, password, filename='backup.vault'):
    salt = os.urandom(16)
    key = generate_key(password, salt)
    data_str = json.dumps(vault_data)
    encrypted = encrypt_data(data_str, key)
    
    with open(filename, "wb") as f:
        f.write(salt + encrypted)  # prepend salt

def import_from_vault(password, filename='backup.vault'):
    with open(filename, "rb") as f:
        content = f.read()
        salt, encrypted = content[:16], content[16:]
        key = generate_key(password, salt)
        try:
            decrypted = decrypt_data(encrypted, key)
            return json.loads(decrypted)
        except Exception as e:
            print("❌ Invalid password or corrupted file.")
            return None

def import_from_csv(csv_path):
    entries = []
    with open(csv_path, newline='', encoding='utf-8') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            entry = {
                "title": row.get("name") or row.get("url"),
                "username": row.get("username"),
                "password": row.get("password"),
                "url": row.get("url"),
                "notes": row.get("notes", ""),
                "tags": [],
            }
            entries.append(entry)
    return entries
