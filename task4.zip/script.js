async function registerUser() {
    const username = document.getElementById("username").value;

    const publicKey = {
        challenge: Uint8Array.from("randomchallenge123", c => c.charCodeAt(0)),
        rp: { name: "Biometric Vault" },
        user: {
            id: Uint8Array.from(username, c => c.charCodeAt(0)),
            name: username,
            displayName: username
        },
        pubKeyCredParams: [{ type: "public-key", alg: -7 }],
        authenticatorSelection: {
            authenticatorAttachment: "platform",
            userVerification: "required"
        },
        timeout: 60000,
        attestation: "none"
    };

    try {
        const credential = await navigator.credentials.create({ publicKey });
        const credJSON = {
            id: credential.id,
            type: credential.type,
            rawId: btoa(String.fromCharCode(...new Uint8Array(credential.rawId)))
        };

        await fetch("/register", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ username, credential: credJSON })
        });

        alert("✅ Biometric registered!");
    } catch (err) {
        alert("❌ Registration failed: " + err);
    }
}

async function loginUser() {
    const username = document.getElementById("username").value;
    const publicKey = {
        challenge: Uint8Array.from("randomchallenge123", c => c.charCodeAt(0)),
        allowCredentials: [],
        timeout: 60000,
        userVerification: "required"
    };

    try {
        const assertion = await navigator.credentials.get({ publicKey });
        const credJSON = {
            id: assertion.id,
            type: assertion.type,
            rawId: btoa(String.fromCharCode(...new Uint8Array(assertion.rawId)))
        };

        const res = await fetch("/authenticate", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ username, credential: credJSON })
        });

        if (res.status === 200) {
            alert("🔓 Authenticated! Access granted to Vault.");
            document.getElementById("vault").style.display = "block";
        } else {
            alert("❌ Authentication failed!");
        }
    } catch (err) {
        alert("❌ Login failed: " + err);
    }
}
