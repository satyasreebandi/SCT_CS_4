import sqlite3
from utils import hash_password, verify_password, generate_key

DB_PATH = "db.sqlite3"

def init_db():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            username TEXT PRIMARY KEY,
            email TEXT,
            password TEXT,
            aes_key TEXT
        )
    ''')
    conn.commit()
    conn.close()

def register_user(username, email, password):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM users WHERE username = ?", (username,))
    if cursor.fetchone():
        return "Username already exists."
    
    hashed = hash_password(password)
    aes_key = generate_key().decode()

    cursor.execute("INSERT INTO users (username, email, password, aes_key) VALUES (?, ?, ?, ?)",
                   (username, email, hashed, aes_key))
    conn.commit()
    conn.close()

    open(f"vault_{username}.enc", "wb").close()
    return "User registered successfully."

def login_user(username, password):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT password, aes_key FROM users WHERE username = ?", (username,))
    row = cursor.fetchone()
    conn.close()

    if not row:
        return None, "User not found"
    
    stored_hash, aes_key = row
    if verify_password(password, stored_hash):
        return aes_key.encode(), "Login successful"
    else:
        return None, "Invalid password"
