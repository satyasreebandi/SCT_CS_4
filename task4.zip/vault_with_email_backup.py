import os
import smtplib
import tkinter as tk
from tkinter import messagebox
from email.message import EmailMessage
from cryptography.fernet import Fernet
import datetime

# === CONFIGURATION ===
EMAIL_ADDRESS = "satyabandibandi@gmail.com"          # Change this to your email
EMAIL_APP_PASSWORD = "euveresnoljhjsyv"# Use Gmail App Password
BACKUP_RECEIVER = EMAIL_ADDRESS                 # You can send to yourself

VAULT_FILE = "vault.enc"
KEY_FILE = "vault.key"

# === ENCRYPTION SETUP ===
def generate_key():
    key = Fernet.generate_key()
    with open(KEY_FILE, "wb") as key_file:
        key_file.write(key)

def load_key():
    if not os.path.exists(KEY_FILE):
        generate_key()
    with open(KEY_FILE, "rb") as key_file:
        return key_file.read()

fernet = Fernet(load_key())

# === EMAIL SENDER ===
def send_email_backup(file_path):
    try:
        msg = EmailMessage()
        msg['Subject'] = "🔐 Encrypted Vault Backup"
        msg['From'] = EMAIL_ADDRESS
        msg['To'] = BACKUP_RECEIVER
        msg.set_content(f"Encrypted vault backup created on {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

        with open(file_path, "rb") as f:
            file_data = f.read()
            file_name = os.path.basename(file_path)

        msg.add_attachment(file_data, maintype="application", subtype="octet-stream", filename=file_name)

        with smtplib.SMTP_SSL("smtp.gmail.com", 465) as smtp:
            smtp.login(EMAIL_ADDRESS, EMAIL_APP_PASSWORD)
            smtp.send_message(msg)

        print("📧 Email backup sent successfully.")
    except Exception as e:
        print("❌ Failed to send email backup:", e)

# === SAVE PASSWORD FUNCTION ===
def save_password():
    website = entry_website.get()
    username = entry_username.get()
    password = entry_password.get()

    if not website or not username or not password:
        messagebox.showwarning("Missing Info", "Please fill all fields.")
        return

    data = f"Website: {website}\nUsername: {username}\nPassword: {password}\n{'-'*30}\n"
    encrypted = fernet.encrypt(data.encode())

    with open(VAULT_FILE, "ab") as f:
        f.write(encrypted + b"\n")

    send_email_backup(VAULT_FILE)
    messagebox.showinfo("Saved", "Password saved & backup emailed!")

# === VIEW PASSWORD FUNCTION ===
def view_passwords():
    if not os.path.exists(VAULT_FILE):
        messagebox.showinfo("Empty", "No saved passwords.")
        return

    top = tk.Toplevel(root)
    top.title("Saved Passwords")
    text = tk.Text(top, width=60, height=20)
    text.pack()

    with open(VAULT_FILE, "rb") as f:
        for line in f:
            try:
                decrypted = fernet.decrypt(line.strip()).decode()
                text.insert(tk.END, decrypted + "\n")
            except:
                continue

# === GUI SETUP ===
root = tk.Tk()
root.title("🔐 Vault with Email Backup")

tk.Label(root, text="Website:").grid(row=0, column=0, padx=5, pady=5)
entry_website = tk.Entry(root, width=40)
entry_website.grid(row=0, column=1, padx=5)

tk.Label(root, text="Username:").grid(row=1, column=0, padx=5, pady=5)
entry_username = tk.Entry(root, width=40)
entry_username.grid(row=1, column=1, padx=5)

tk.Label(root, text="Password:").grid(row=2, column=0, padx=5, pady=5)
entry_password = tk.Entry(root, width=40, show="*")
entry_password.grid(row=2, column=1, padx=5)

tk.Button(root, text="💾 Save Password", command=save_password).grid(row=3, column=0, columnspan=2, pady=10)
tk.Button(root, text="📂 View Passwords", command=view_passwords).grid(row=4, column=0, columnspan=2)

root.mainloop()
