# gui_app.py

import tkinter as tk
from tkinter import filedialog, messagebox
from encrypt_log import encrypt_log_file

def browse_file():
    file_path = filedialog.askopenfilename(initialdir="logs", title="Select Log File")
    if file_path:
        file_entry.delete(0, tk.END)
        file_entry.insert(0, file_path)

def encrypt_and_send():
    file_path = file_entry.get()
    password = password_entry.get()

    if not file_path or not password:
        messagebox.showwarning("Missing Info", "Please select a file and enter password.")
        return

    result = encrypt_log_file(file_path, password)
    status_label.config(text=result)

# GUI Window
root = tk.Tk()
root.title("Log Encryptor & Sender")
root.geometry("400x250")
root.resizable(False, False)

# Widgets
tk.Label(root, text="Select Log File:").pack(pady=5)
file_entry = tk.Entry(root, width=40)
file_entry.pack()
tk.Button(root, text="Browse", command=browse_file).pack(pady=5)

tk.Label(root, text="Enter Password:").pack(pady=5)
password_entry = tk.Entry(root, width=40, show="*")
password_entry.pack()

tk.Button(root, text="Encrypt & Email", command=encrypt_and_send, bg="#4CAF50", fg="white").pack(pady=10)

status_label = tk.Label(root, text="", fg="blue")
status_label.pack(pady=10)

root.mainloop()
