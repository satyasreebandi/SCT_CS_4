from cryptography.fernet import Fernet
import os

# === Step 1: Load or Create Secret Key ===
def load_or_create_key():
    key_file = "secret.key"
    if os.path.exists(key_file):
        with open(key_file, "rb") as f:
            return f.read()
    else:
        key = Fernet.generate_key()
        with open(key_file, "wb") as f:
            f.write(key)
        return key

key = load_or_create_key()
fernet = Fernet(key)

# === Step 2: Save a Password (Optional) ===
def save_password(password):
    encrypted = fernet.encrypt(password.encode())
    with open("strong_passwords.enc", "ab") as f:
        f.write(encrypted + b"\n")
    print("✅ Password saved and encrypted.")

# === Step 3: View Encrypted Passwords ===
def view_encrypted_passwords():
    try:
        with open("strong_passwords.enc", "rb") as f:
            print("\n📂 Decrypted Passwords:")
            for line in f:
                decrypted = fernet.decrypt(line.strip()).decode()
                print(" -", decrypted)
    except FileNotFoundError:
        print("❌ No encrypted password file found.")
    except Exception as e:
        print("❌ Error decrypting passwords:", e)

# === Step 4: Main Program ===
def main():
    print("🔐 Welcome to Secure Password Manager")
    while True:
        print("\nMenu:")
        print("1. Save a new password")
        print("2. View saved passwords")
        print("3. Exit")
        choice = input("Enter your choice (1/2/3): ")

        if choice == '1':
            password = input("Enter password to save: ")
            save_password(password)
        elif choice == '2':
            view_encrypted_passwords()
        elif choice == '3':
            print("👋 Goodbye!")
            break
        else:
            print("❌ Invalid choice. Try again.")

if __name__ == "__main__":
    main()
