import tkinter as tk
from tkinter import messagebox
import re
import os

# ------------------- Strength Check Function -------------------
def check_strength(password):
    strength = 0
    if len(password) >= 8:
        strength += 1
    if re.search(r"[A-Z]", password):
        strength += 1
    if re.search(r"[a-z]", password):
        strength += 1
    if re.search(r"[0-9]", password):
        strength += 1
    if re.search(r"[!@#$%^&*(),.?\":{}|<>]", password):
        strength += 1

    if strength <= 2:
        return "Weak ❌"
    elif strength == 3 or strength == 4:
        return "Moderate ⚠️"
    else:
        return "Strong ✅"

# ------------------- Button Functions -------------------
def evaluate_password():
    pwd = password_entry.get()
    if not pwd:
        messagebox.showwarning("Input Error", "Please enter a password.")
        return
    result = check_strength(pwd)
    strength_var.set(f"Strength: {result}")

def save_password():
    pwd = password_entry.get()
    if not pwd:
        messagebox.showwarning("Input Error", "Please enter a password.")
        return
    with open("strong_passwords.txt", "a") as f:
        f.write(pwd + "\n")
    messagebox.showinfo("Saved", "✅ Password saved successfully!")

def view_passwords():
    if not os.path.exists("strong_passwords.txt"):
        messagebox.showinfo("No Data", "No passwords saved yet.")
        return
    with open("strong_passwords.txt", "r") as f:
        passwords = f.read()
    messagebox.showinfo("Saved Passwords", passwords if passwords else "No passwords saved.")

# ------------------- GUI Setup -------------------
root = tk.Tk()
root.title("🔐 Password Strength Checker")
root.geometry("400x300")
root.config(bg="#f0f0f0")

tk.Label(root, text="Enter Password:", font=("Arial", 12), bg="#f0f0f0").pack(pady=10)

password_entry = tk.Entry(root, show="*", width=30, font=("Arial", 12))
password_entry.pack(pady=5)

tk.Button(root, text="Check Strength", command=evaluate_password, bg="#4caf50", fg="white").pack(pady=5)

strength_var = tk.StringVar()
tk.Label(root, textvariable=strength_var, font=("Arial", 12, "bold"), fg="blue", bg="#f0f0f0").pack(pady=5)

tk.Button(root, text="💾 Save Password", command=save_password, bg="#2196f3", fg="white").pack(pady=5)
tk.Button(root, text="📂 View Saved", command=view_passwords, bg="#9c27b0", fg="white").pack(pady=5)

root.mainloop()
