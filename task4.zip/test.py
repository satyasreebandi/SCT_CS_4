from user_manager import init_db, register_user, login_user
from vault_manager import save_to_vault, read_vault

# Initialize database
init_db()

# Register user
print(register_user("alice", "alice@example.com", "alice123"))

# Login
key, msg = login_user("alice", "alice123")
print(msg)

# Save and read vault
if key:
    save_to_vault("alice", key, "My top secret passwords and notes")
    print("Vault Content:", read_vault("alice", key))
