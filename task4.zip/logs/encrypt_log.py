# encrypt_log.py

import os
import smtplib
import base64
from email.message import EmailMessage
from cryptography.fernet import Fernet
from datetime import datetime
from pathlib import Path
from getpass import getpass
from email.utils import make_msgid
import hashlib

def encrypt_log_file(log_path, password):
    logs_dir = Path("logs")
    log_file = Path(log_path)

    if not log_file.exists():
        return "❌ Log file not found."

    # Generate key using password
    key = hashlib.sha256(password.encode()).digest()
    key = base64.urlsafe_b64encode(key[:32])
    fernet = Fernet(key)

    with open(log_file, "rb") as file:
        data = file.read()
    encrypted = fernet.encrypt(data)

    output_path = logs_dir / f"log_{datetime.now():%Y%m%d_%H%M%S}.txt.enc"
    with open(output_path, "wb") as f:
        f.write(encrypted)

    os.remove(log_file)
    
    # Send email (optional, simplify for now)
    try:
        send_email(output_path)
        return f"✅ Encrypted and emailed: {output_path.name}"
    except Exception as e:
        return f"✅ Encrypted but ❌ Email failed: {str(e)}"

def send_email(file_path):
    EMAIL = "satyabandibandi@gmail.com"
    APP_PASSWORD = "euveresnoljhjsyv"
    TO_EMAIL = "sirichowdary1917@gmail.com"

    msg = EmailMessage()
    msg["Subject"] = "Encrypted Log File"
    msg["From"] = EMAIL
    msg["To"] = TO_EMAIL

    msg.set_content("Attached is your encrypted log file.")

    with open(file_path, "rb") as f:
        data = f.read()
        msg.add_attachment(data, maintype="application", subtype="octet-stream", filename=file_path.name)

    with smtplib.SMTP_SSL("smtp.gmail.com", 465) as smtp:
        smtp.login(EMAIL, APP_PASSWORD)
        smtp.send_message(msg)
