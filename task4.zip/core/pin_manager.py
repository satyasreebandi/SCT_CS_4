import os
from core.encryption import derive_key_from_pin, get_fernet

PIN_FILE = "data/pin_key.enc"

def save_encrypted_vault_key(master_key: bytes, pin: str):
    # 🔧 Ensure data/ folder exists
    os.makedirs("data", exist_ok=True)

    salt = os.urandom(16)
    derived_key = derive_key_from_pin(pin, salt)
    fernet = get_fernet(derived_key)
    encrypted = fernet.encrypt(master_key)

    with open(PIN_FILE, "wb") as f:
        f.write(salt + encrypted)

def load_vault_key_from_pin(pin: str) -> bytes:
    with open(PIN_FILE, "rb") as f:
        content = f.read()
        salt, encrypted_key = content[:16], content[16:]
    derived_key = derive_key_from_pin(pin, salt)
    fernet = get_fernet(derived_key)
    return fernet.decrypt(encrypted_key)
