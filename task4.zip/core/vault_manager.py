import json
import os
from core.encryption import get_fernet

VAULT_FILE = "data/vault.enc"

def encrypt_and_save_vault(data: list, key: bytes):
    f = get_fernet(key)
    encrypted = f.encrypt(json.dumps({"entries": data}).encode())
    with open(VAULT_FILE, "wb") as f_out:
        f_out.write(encrypted)

def load_and_decrypt_vault(key: bytes) -> list:
    if not os.path.exists(VAULT_FILE):
        return []
    f = get_fernet(key)
    with open(VAULT_FILE, "rb") as f_in:
        decrypted = f.decrypt(f_in.read())
        return json.loads(decrypted.decode())["entries"]

def add_entry(entry: dict, key: bytes):
    entries = load_and_decrypt_vault(key)
    entries.append(entry)
    encrypt_and_save_vault(entries, key)

def update_entry(index: int, updated_entry: dict, key: bytes):
    entries = load_and_decrypt_vault(key)
    if 0 <= index < len(entries):
        entries[index] = updated_entry
        encrypt_and_save_vault(entries, key)

def delete_entry(index: int, key: bytes):
    entries = load_and_decrypt_vault(key)
    if 0 <= index < len(entries):
        del entries[index]
        encrypt_and_save_vault(entries, key)
