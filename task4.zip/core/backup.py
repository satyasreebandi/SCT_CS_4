import os
import shutil
import smtplib
from email.message import EmailMessage

VAULT_FILE = "data/vault.enc"

def create_local_backup():
    if not os.path.exists(VAULT_FILE):
        print("❌ Vault file not found. Add at least one entry before backup.")
        return None

    os.makedirs("data/backups", exist_ok=True)
    backup_path = "data/backups/vault_backup.enc"
    shutil.copy(VAULT_FILE, backup_path)
    print(f"✅ Backup saved to: {backup_path}")
    return backup_path


def send_email_backup_prompt():
    print("\n📧 Email Backup Setup:")
    from_email = input("Enter your Gmail address (e.g. user@gmail.com): ").strip()
    to_email = input("Enter recipient email address (can be same): ").strip()
    app_password = input("Enter your Gmail App Password (not your regular password): ").strip()

    backup_file = create_local_backup()
    if not backup_file:
        return

    msg = EmailMessage()
    msg['Subject'] = "🔐 Encrypted Vault Backup"
    msg['From'] = from_email
    msg['To'] = to_email
    msg.set_content("Attached is your encrypted password vault backup.")

    try:
        with open(backup_file, 'rb') as f:
            file_data = f.read()
            msg.add_attachment(file_data, maintype="application", subtype="octet-stream", filename="vault_backup.enc")

        with smtplib.SMTP_SSL("smtp.gmail.com", 465) as smtp:
            smtp.login(from_email, app_password)
            smtp.send_message(msg)

        print("✅ Encrypted backup sent successfully via email.")
    except smtplib.SMTPAuthenticationError:
        print("❌ Authentication failed! Use a valid Gmail address with a correct App Password.")
    except Exception as e:
        print(f"❌ Failed to send email: {e}")
