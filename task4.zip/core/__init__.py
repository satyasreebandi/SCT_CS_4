# core/__init__.py
# This file marks the 'core' folder as a Python package.
# You can leave it empty or use it to initialize shared variables if needed.
