from encryptor import load_key
from config import get_log_filename
import os

def view_logs():
    f = load_key()
    log_file = get_log_filename()

    if not os.path.exists(log_file):
        print("❌ No log file found.")
        return

    with open(log_file, 'rb') as log:
        for line in log:
            try:
                print(f.decrypt(line).decode())
            except:
                print("[!] Could not decrypt line")

if __name__ == "__main__":
    view_logs()
